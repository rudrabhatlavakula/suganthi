/*var gulp = require('gulp');
var nunjucksRender = require('gulp-nunjucks-render');
var template = require('gulp-template');
var wrap = require('gulp-wrap');

//gulp.task('default', ['nunjucks']);
 gulp.task('build', function () {
    console.log('Building...');
  });
  
 

gulp.task('nunjucks', function () {
    nunjucksRender.nunjucks.configure(['templates/'], { watch: false });
    return gulp.src('templates/!(_)*.html')
        .pipe(nunjucksRender({
        	css_path: "../assets/css/",
        	js_path: "../assets/js/",
        	img_path: "../assets/images/"
        }))
        .pipe(gulp.dest('html'));
});
gulp.task('watch', function () {
    gulp.watch(['templates/*.html'], ['default']);
});
*/

// gulpfile.js
var gulp              = require('gulp');
var nunjucks = require('gulp-nunjucks-html');
var open = require('gulp-open');
var connect = require('gulp-connect');
var opn       = require('opn');
var browser = 'chrome';

gulp.task('default', ['webserver']);

 
gulp.task('nunjucks', function() {
  return gulp.src('D:/sample/app/pages/**/*.html')
    .pipe(nunjucks({
      searchPaths: ['D:/sample/app/templates']
    }))
    .pipe(gulp.dest('D:/sample/app/html'));
});
   /*gulp.task('default', function () {	
	var http = require("http");  
	http.createServer(function (request, response) {  
		response.writeHead(200, {'Content-Type': 'text/plain'});     
		response.end('Hi \n'); 
	}).listen(8080);	
	console.log('Server running at http://127.0.0.1:8080/'); 	 
  });*/  
  
  /*gulp.task('open', function(){
  gulp.src('D:/sample/app/html/index.html')
  .pipe(open({app: browser}));
});*/
/*gulp.task('app', function(){
  var options = {
    uri: 'http://localhost:8080',
    app: browser
  };
 gulp.src('D:/sample/app/html/index.html')
  .pipe(open(options));
});
*/
/*gulp.task('open', function () {
    return gulp.src('D:/sample/app/html/index.html')
        .pipe(open('', {
            url: 'http://localhost:8080/',
            app: browser
        }));
});*/

gulp.task('webserver', function() {
  connect.server();
  opn( 'http://localhost:8080/html/' );
});



